	<!DOCTYPE html>
	<html lang="es">
	<head>
		<meta charset="UTF-8">
		<title>Dados </title>
	</head>
	<body>

	<?php

	// Jugador 1
	$d1 = rand(1,6);
	$d2 = rand(1,6);
	$d3 = rand(1,6);
	$d4 = rand(1,6);
	$d5 = rand(1,6);
	$d6 = rand(1,6);

	$total1 = $d1 + $d2 + $d3 + $d4 + $d5 + $d6;

	echo "<h1>Jugador 1</h1>";
	echo "<p>";
	echo "<img src='img/$d1.jpg' height='120'>";
	echo "<img src='img/$d2.jpg' height='120'>";
	echo "<img src='img/$d3.jpg' height='120'>";
	echo "<img src='img/$d4.jpg' height='120'>";
	echo "<img src='img/$d5.jpg' height='120'>";
	echo "<img src='img/$d6.jpg' height='120'>";
	echo "</p>";

	echo "<p>Total: <b>$total1</b></p>";

	// Jugador 2
	$d7 = rand(1,6);
	$d8 = rand(1,6);
	$d9 = rand(1,6);
	$d10 = rand(1,6);
	$d11 = rand(1,6);
	$d12 = rand(1,6);

	$total2 = $d7 + $d8 + $d9 + $d10 + $d11 + $d12;

	echo "<h1>Jugador 2</h1>";
	echo "<p>";
	echo "<img src='img/$d7.jpg' height='120'>";
	echo "<img src='img/$d8.jpg' height='120'>";
	echo "<img src='img/$d9.jpg' height='120'>";
	echo "<img src='img/$d10.jpg' height='120'>";
	echo "<img src='img/$d11.jpg' height='120'>";
	echo "<img src='img/$d12.jpg' height='120'>";
	echo "</p>";

	echo "<p>Total: <b>$total2</b></p>";

	// Resultado
	echo "<h2>Resultado</h2>";

	if ($total1 > $total2) {
		echo "<p>Gana el Jugador 1</p>";
	} elseif ($total2 > $total1) {
		echo "<p>Gana el Jugador 2</p>";
	} else {
		echo "<p>Empate</p>";
	}

	?>

	</body>
	</html>
