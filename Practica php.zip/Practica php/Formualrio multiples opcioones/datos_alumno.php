<?php
// Recoger y limpiar datos
$nombre = strip_tags(trim($_POST["nombre"]));
$telefono = strip_tags(trim($_POST["telefono"]));
$ensenanza = strip_tags(trim($_POST["ensenanza"]));
$mostrar = strip_tags(trim($_POST["mostrar"]));

// Matriculado checkbox
if (isset($_POST["matriculado"])) {
    $matriculado = "matriculado";
} else {
    $matriculado = "no matriculado";
}

// Texto final
$texto = "El alumno $nombre, con teléfono $telefono, está $matriculado en $ensenanza.";

// Opción 1 → Mostrar por pantalla
if ($mostrar == "-1") {
    echo $texto;
}

// Opción 2 → Guardar en datos.txt y mostrar enlace
if ($mostrar == "1") {

    $archivo = "datos.txt";

    // Guardar texto
    $f = fopen($archivo, "a");
    fwrite($f, $texto . "\n");
    fclose($f);

    echo "<h1>Datos guardados correctamente.</h1><br><br>";
   
}
?>
