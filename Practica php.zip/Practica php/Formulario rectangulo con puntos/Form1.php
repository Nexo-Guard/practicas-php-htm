
<?php
// Sanitización y obtención de datos
$ancho = trim(strip_tags($_REQUEST["n1"]));
$alto = trim(strip_tags($_REQUEST["n2"]));
$validarOk = false;

// Validación de entrada
if (empty($ancho) || empty($alto)) {
    echo "<p class='error'>Por favor, complete ambos campos.</p>";
} elseif (!is_numeric($ancho) || !is_numeric($alto)) {
    echo "<p class='error'>Introduce valores numéricos válidos.</p>";
} elseif ($ancho <= 0 || $alto <= 0 || $ancho > 100 || $alto > 100) {
    echo "<p class='error'>Los valores deben estar entre 1 y 100.</p>";
} else {
    $validarOk = true;
}

// Generación del rectángulo
if ($validarOk === true) {
    echo "<div class='resultado'>";
    echo "<p><strong>Alto:</strong> $alto</p>";
    echo "<p><strong>Ancho:</strong> $ancho</p>";
    echo "<div class='rectangulo'>";
    
    for ($i = 1; $i <= $alto; $i++) {
        for ($j = 1; $j <= $ancho; $j++) {
            echo "*";
        }
        echo "<br>";
    }
    
    echo "</div>";
    echo "</div>";
}
?>
