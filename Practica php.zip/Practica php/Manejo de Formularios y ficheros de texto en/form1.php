       

  <?php
    // Parte 1: Guardar contactos
    if ($_POST["nombre"]) {
        $nombre = $_POST["nombre"];
        $trabajo = $_POST["trabajo"];
        $telefono = $_POST["telefono"];
        $direccion = $_POST["direccion"];
        $otras = $_POST["otras"];
        
        $miarchivo = fopen("agenda.txt", "a");
        
        fwrite($miarchivo, $nombre);
        fwrite($miarchivo, "|");
        fwrite($miarchivo, $trabajo);
        fwrite($miarchivo, "|");
        fwrite($miarchivo, $telefono);
        fwrite($miarchivo, "|");
        fwrite($miarchivo, $direccion);
        fwrite($miarchivo, "|");
        fwrite($miarchivo, $otras);
        fwrite($miarchivo, "\n");
        
        fclose($miarchivo);
        
        echo "<div class='mensaje'>El contacto se guardo bien!</div>";
    }
    ?>




	   <?php
        // Parte 2: Buscar contactos
        if ($_POST["buscar"]) {
            $nombreBuscar = $_POST["nombreBuscar"];
            
            echo "<h4>Resultados de la busqueda:</h4>";
            
            if (file_exists("agenda.txt")) {
                $miarchivo = fopen("agenda.txt", "r");
                
                $encontrado = 0;
                
                $linea = fgets($miarchivo);
                while ($linea) {
                    if (strpos($linea, $nombreBuscar) !== false) {
                        $encontrado = 1;
                        
                        $datos = explode("|", $linea);
                        
                        echo "<div style='background: white; padding: 10px; margin: 10px 0; border: 1px solid #ccc;'>";
                        echo "<strong>Nombre:</strong> " . $datos[0] . "<br>";
                        echo "<strong>Trabajo:</strong> " . $datos[1] . "<br>";
                        echo "<strong>Telefono:</strong> " . $datos[2] . "<br>";
                        echo "<strong>Dirección:</strong> " . $datos[3] . "<br>";
                        echo "<strong>Otras:</strong> " . $datos[4];
                        echo "</div>";
                    }
                    $linea = fgets($miarchivo);
                }
                
                fclose($miarchivo);
                
                if ($encontrado == 0) {
                    echo "<p>No se encontro ningun contacto con ese nombre.</p>";
                }
            } else {
                echo "<p>No hay contactos todavia.</p>";
            }
        }
        ?>
		 <?php
        // Parte 3: Mostrar todos los contactos
        if (file_exists("agenda.txt")) {
            $miarchivo = fopen("agenda.txt", "r");
            
            $linea = fgets($miarchivo);
            while ($linea) {
                if ($linea != "") {
                    $datos = explode("|", $linea);
                    
                    echo "<div style='background: white; padding: 10px; margin: 10px 0; border: 1px solid #ccc;'>";
                    echo "<strong>Contacto:</strong> " . $datos[0] ." " . $datos[1] . " " . $datos[2] ." " . $datos[3] ." ".   $datos[4] . "<br>";
                    echo "</div>";
                }
                $linea = fgets($miarchivo);
            }
            
            fclose($miarchivo);
        } else {
            echo "<p>No hay contactos todavia.</p>";
        }
        ?>