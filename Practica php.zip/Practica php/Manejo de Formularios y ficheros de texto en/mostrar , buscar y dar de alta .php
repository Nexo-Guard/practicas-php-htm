<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Agenda Virtual PHP</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 30px;
        }
        h1 {
            font-size: 32px;
        }
        h3 {
            margin-top: 30px;
            color: #333;
        }
        label {
            display: block;
            margin-top: 10px;
            font-weight: bold;
        }
        input {
            width: 300px;
            padding: 6px;
            margin-top: 4px;
        }
        button {
            margin-top: 15px;
            padding: 8px 15px;
        }
        .contactos {
            margin-top: 30px;
            padding: 15px;
            background-color: #f0f0f0;
        }
        .busqueda {
            margin-top: 30px;
            padding: 15px;
            background-color: #e8f4f8;
        }
        .mensaje {
            padding: 10px;
            margin: 10px 0;
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .separador {
            border-top: 2px solid #ccc;
            margin: 40px 0;
        }
    </style>
</head>
<body>
    <h2>Agenda Virtual PHP</h2>
    <h1>Contactos</h1>
   
    
    <h3>Dar de alta nuevo contacto</h3>
    <p>Para guardar presione el boton</p>
    <form action="form1.php" method="post">
        <label>Nombre:
            <input type="text" name="nombre" required>
        </label>
        <label>Trabajo:
            <input type="text" name="trabajo">
        </label>
        <label>Telefono:
            <input type="text" name="telefono">
        </label>
        <label>Dirección:
            <input type="text" name="direccion">
        </label>
        <label>Otras:
            <input type="text" name="otras">
        </label>
        <button type="submit">Guardar!</button>
        <button type="reset">Reset</button>
    </form>
    
    <div class="separador"></div>
    
    <div class="busqueda">
        <h3>Buscar contacto</h3>
        <form action="form1.php" method="post">
            <label>Nombre a buscar:
                <input type="text" name="nombreBuscar">
            </label>
            <button type="submit" name="buscar" value="si">Buscar</button>
        </form>
        
       
    </div>
    
    <div class="separador"></div>
    
   
</body>
</html>